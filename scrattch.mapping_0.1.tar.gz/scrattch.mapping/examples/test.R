## Load scrattch.mapping
library(scrattch.mapping)

## Load in example count data
library(tasic2016data)

## Compute log CPM
query.data = tasic_2016_counts
query.data = logCPM(query.data)

## Specify which taxonomies to map against. Let's map against one we made in the "build_taxonomy" example.
taxonomies = c("/allen/programs/celltypes/workgroups/rnaseqanalysis/shiny/10x_seq/tasic_2016")

## Map data against all taxonomies
mapping.anno = list()
for(taxonomy in taxonomies){
    ## Load the shiny taxonomy into a standard object for mapping.
    AIT.anndata = loadTaxonomy(refFolder = taxonomy)
    ## Map! Returns a data.frame with mapping results.
    mapping.anno[[taxonomy]] = taxonomy_mapping(AIT.anndata=AIT.anndata, 
                                                query.data=query.data, 
                                                label.cols="cluster_label",
                                                corr.map=TRUE, 
                                                tree.map=TRUE, 
                                                seurat.map=TRUE)
}