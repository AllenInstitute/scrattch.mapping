## ----create reference directory-----------------------------------------------
# REPLACE THIS LINE WITH the reference directory folder from "Map patch-seq data and output directory"
refFolder <- paste0(system.file(package = 'scrattch.mapping'),"/reference/")  
# Replace this line with wherever you'd like your comparison output
mappingFolder <- paste0(refFolder,"/comparisons/")
dir.create(mappingFolder, showWarnings = FALSE)
print(mappingFolder)

## ----load libraries, warning=FALSE--------------------------------------------
suppressPackageStartupMessages({
  library("scrattch.mapping")
})
options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 4000 * 1024^2)  # Can adjust this value if needed, or omit, depending on number of cells
options(future.rng.onMisuse="ignore")

## ----load reference taxonomy--------------------------------------------------
AIT.anndata <- read_h5ad(file.path(refFolder,"reference.h5ad"))

## ----load tasic data----------------------------------------------------------
query.metadata <- AIT.anndata$obs
query.logCPM   <- t(AIT.anndata$X)  # Stored as gene x cell in anndata, so must be transposed

## ----general mapping----------------------------------------------------------
query.mapping <- taxonomy_mapping(AIT.anndata= AIT.anndata,
                                  query.data = query.logCPM, 
                                  corr.map   = TRUE, # Flags for which mapping algorithms to run
                                  tree.map   = TRUE, 
                                  seurat.map = TRUE, 
                                  label.cols = c("cluster_label","subclass_label", "class_label") # Columns to map against
)
head(query.mapping)

## ----append clustering--------------------------------------------------------
query.mapping$cluster <- query.metadata$cluster
clusters <- levels(query.metadata$cluster)

methods  <- c("cluster","cluster_Corr", "cluster_Seurat","cluster_Tree")
names(methods) <- c("Clustering","Correlation.Mapping","Seurat.Mapping","Tree.Mapping")
for(m in methods)
  query.mapping[,m] <- factor(query.mapping[,m],levels=clusters)

## ----quick method comparison facs---------------------------------------------
compare <- matrix(0,nrow=4,ncol=4)
rownames(compare) <- colnames(compare) <- names(methods)
for(m1 in 1:4) for(m2 in 1:4) 
  compare[m1,m2] = mean(query.mapping[,methods[m1]]==query.mapping[,methods[m2]])
data.frame(compare)

## ----plot comparison, fig.height=5, fig.width=16------------------------------
p <- map <- list()
clust <- query.mapping[,methods[1]]
for (i in 1:3){
  map[[i]] <- query.mapping[,methods[i+1]]
  p[[i]]   <- compare_plot(map[[i]],clust) + xlab(names(methods[i+1])) + ylab("Clustering")
}
plot_grid(p[[1]], p[[2]], p[[3]], ncol=3)

## ----visualize heatmap, fig.height=8, fig.width=8-----------------------------
for (i in 1:3){
  compare_heatmap(map[[i]],clust,xlab=names(methods[i+1]),ylab="Clustering", cex.lab=0.3)
}

## ----calculate cluster compactness--------------------------------------------
variable.features <- colnames(AIT.anndata$X)[AIT.anndata$var$highly_variable_genes]
compactness       <- compactness_distance(query.logCPM, clust, variable.features=variable.features)
for(i in 1:3)
  compactness <- cbind(compactness, compactness_distance(query.logCPM, map[[i]], variable.features=variable.features))
colnames(compactness) <- names(methods)

## ----cluster compactness comparison, fig.height=5, fig.width=5----------------
par(mfrow=c(4,1))
par(mar=c(1,4,0.1,0.1))
for (i in 1:4){
  plot(density(compactness[,i]),xlim=c(0,0.5),ylim=c(0,7),lwd=3,main="",xlab="",ylab=names(methods)[i])
  abline(v=(0:5)/10,col="grey",lty="dotted")
  abline(v=median(compactness[,i]),lwd=2,col="green")
}

## ----calculate transgenic distance--------------------------------------------
query.secondary <- paste(query.metadata$cre_driver_1_label,query.metadata$tdTomato_label)
trans.distance  <- compactness_distance(query.logCPM, clust, query.secondary, variable.features=variable.features)
for(i in 1:3)
  trans.distance <- cbind(trans.distance, compactness_distance(query.logCPM, map[[i]], query.secondary, variable.features=variable.features))
colnames(trans.distance) <- names(methods)

## ----transgenic distance comparison, fig.height=5, fig.width=5----------------
par(mfrow=c(4,1))
par(mar=c(1,4,0.1,0.1))
for (i in 1:4){
  plot(density(trans.distance[,i]),xlim=c(0,0.5),ylim=c(0,7),lwd=3,main="",xlab="",ylab=names(methods)[i])
  abline(v=(0:5)/10,col="grey",lty="dotted")
  abline(v=median(trans.distance[,i]),lwd=2,col="green")
}

## ----FACS value comparison, fig.height=5, fig.width=5-------------------------
core = setNames(substr(query.metadata$core_intermediate_label,1,5),colnames(query.logCPM))
df = NULL
for (n in c("Corr","Seurat","Tree")){
  df = rbind(df,data.frame(core=core, score=query.mapping[,paste0("score.",n)], method=n))
}
e  <- ggplot(df, aes(x = method, y = score))
e2 <- e + geom_boxplot(aes(fill = core), position = position_dodge(0.9)) +
  scale_fill_manual(values = c("#999999", "#E69F00"))
e2

## ----vis plots, warning=FALSE, fig.height=6, fig.width=8----------------------
# Need to format the mapping results for plotting.
columns <- c("correlation_mapping","seurat_mapping","tree_mapping")
plotDat <- data.frame(sample_name = rownames(query.mapping), 
                      tree_mapping = query.mapping$score.Corr, 
                      seurat_mapping = query.mapping$score.Seurat, 
                      correlation_mapping = query.mapping$score.Tree)  
annoDat <- data.frame(sample_name = rownames(query.mapping), 
                      tree_mapping = query.mapping$cluster_Corr, 
                      seurat_mapping = query.mapping$cluster_Seurat, 
                      correlation_mapping = query.mapping$cluster_Tree)
for(cn in columns){
  annoDat <- annotate_cat(annoDat,cn)
  annoDat[,paste0(cn,"_id")] <- query.metadata$cluster_id[match(annoDat[,paste0(cn,"_label")],query.metadata$cluster_label)]
  annoDat[,paste0(cn,"_color")] <- query.metadata$cluster_color[match(annoDat[,paste0(cn,"_label")],query.metadata$cluster_label)]
}

# Now make the plots
for (i in 1:3)
  p[[i]] = group_quasirandom_plot(plotDat,annoDat,columns[i],columns[i],log_scale=FALSE, max_width=5,label_height=15)
plot_grid(p[[1]],p[[2]],p[[3]],ncol = 1)

## ----sessionInfo--------------------------------------------------------------
sessionInfo()

