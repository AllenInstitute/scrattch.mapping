## ----install data package if needed-------------------------------------------
if(!"tasic2016data" %in% rownames(installed.packages())) {
  devtools::install_github("AllenInstitute/tasic2016data")
}
suppressPackageStartupMessages({
  library(tasic2016data)
})

## ----install CCN if needed----------------------------------------------------
if(!"CCN" %in% rownames(installed.packages())) {
  ## Imported packages
  packages <- c("remotes","jsonlite","data.table","ggplot2","dendextend","dplyr","BiocManager")
  packages <- packages[!(packages %in% installed.packages()[,"Package"])]
  if(length(packages)>0) install.packages(new.packages, repos='http://cran.us.r-project.org')
  BiocManager::install("rols", update=FALSE)

  ## CCN install
  remotes::install_github("AllenInstitute/CCN", build_vignettes = TRUE)
}
suppressPackageStartupMessages({
  library(CCN)
})

## ----create reference directory-----------------------------------------------
# Replace link below with link to directory
refFolder <- paste0(system.file(package = 'scrattch.mapping'),"/reference/") 
dir.create(refFolder, showWarnings = FALSE)
print(refFolder)

## ----load libraries, warning=FALSE--------------------------------------------
suppressPackageStartupMessages({
  library("scrattch.mapping")
})
options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 4000 * 1024^2)  # Can adjust this value if needed, depending on number of cells
options(future.rng.onMisuse="ignore")

## ----load tasic data----------------------------------------------------------
annotations <- tasic_2016_anno
counts      <- tasic_2016_counts  # uncomment if using CPM below
annotations <- annotations[match(colnames(counts),annotations$sample_name),]  # Put them in the correct order
rownames(annotations) <- annotations$sample_name  

# Subsampling to speed up Vignette and removing unclassified cells 
kp          <- (annotations$broad_type!="Unclassified")&(subsampleCells( annotations$primary_type_label,25,seed = 1))
counts      <- counts[,kp]
annotations <- annotations[kp,]

# Remove all genes with no expression to speed up Vignette
counts      <- counts[rowSums(counts)>0,]

## ----add level annotations----------------------------------------------------
# Rename the primary cell type to "cluster"
clusters            <- annotations$primary_type_label[match(1:49,annotations$primary_type_id)]
annotations$cluster <- factor(annotations$primary_type_label, levels=clusters)

# Retain cluster colors
cluster_colors <- setNames(annotations$primary_type_color[match(1:49,annotations$primary_type_id)], clusters)

# Create a class label that groups all non-neurons together
annotations$class <- annotations$broad_type
annotations$class[!is.element(annotations$class,c("GABA-ergic Neuron","Glutamatergic Neuron"))] = "Non-neuronal"

# Create a subclass label (e.g., intermediate resolution between class and cell type)
subclass <- c(rep("CGE",9),rep("MGE",13),"CGE",rep("Exc IT",10),rep("Exc non-IT",9),rep("NN",7))
subclass <- setNames(subclass,annotations$cluster[match(1:49,annotations$cluster_id)])
subclass <- subclass[annotations$cluster]
subclass[annotations$class=="Non-neuronal"] <- annotations$broad_type[annotations$class=="Non-neuronal"]
annotations$subclass <- gsub("Oligodendrocyte Precursor Cell","OPC",subclass)
head(data.frame(annotations[,c("cluster","subclass","class")]))

## ----create UMAP representation, fig.height=8, fig.width=10-------------------
## Get top 1000 genes by a beta (binary) score
binary.genes <- top_binary_genes(counts,annotations$cluster,1000)

## Calculate a UMAP based on these binary genes.
npcs <- 30
pcs  <- prcomp(logCPM(counts)[binary.genes,], scale = TRUE)$rotation
umap.coords <- umap(pcs[,1:npcs])$layout

## View the output as a sanity check
plot(umap.coords[,1],umap.coords[,2],col=annotations$primary_type_color, pch=19, cex=0.5,
     main="",xlab="UMAP 1", ylab="UMAP 2")

## ----build reference folder---------------------------------------------------
buildTaxonomy(counts         = counts,
               meta.data      = annotations,
               feature.set    = binary.genes,
               umap.coords    = umap.coords,
               shinyFolder    = refFolder,
               cluster_colors = cluster_colors,  # Colors are generated if not provided
               metadata_names = NULL,     # If you want to save only selected metadata columns
               subsample      = 100,      # This is the number of cells per cluster
               reorder.dendrogram = TRUE) # This will match the factor order of the clusters to the extent possible

## ----add dendrogram markers---------------------------------------------------
dend <- addDendrogramMarkers(dend      = readRDS(paste0(refFolder,"dend.RData")), 
                             norm.data = paste0(refFolder,"data_t.feather"),
                             metadata  = paste0(refFolder,"anno.feather"),
                             shinyFolder = refFolder, 
                             subsample= 25) # To speed up calculations a bit

## ----CCN, fig.height=6,fig.width=10, warning=FALSE----------------------------
## Create taxonomy and nomenclature standards for this taxonomy
taxonomy_id       <- "CCN202301170"          # Taxonomy ID of format CCN<YYYYMMDD><T>
taxonomy_author   <- "Bosiljka Tasic"        # Person uploading the data and taxonomy
taxonomy_citation <- "10.1038/nn.4216"       # DOI of relevant taxonomy citation, if any
first_label       <- setNames("RNA", 1)      # Prefix for cell set label (adjust text label only)
structure         <- "primary visual cortex" # Brain structure.  Ontology tag is auto-generated.

# Some metadata variables (probably this doesn't need to be edited)
metadata         <- as.data.frame(read_feather(paste0(refFolder,"anno.feather")))
metadata_columns <- c("subclass_label", "class_label")
metadata_order   <- c("subclass_order", "class_order")  
cluster_column   <- "cluster_label" 

# Named vector of cell to cell type assignments (can be auto-generated, but better to include)
cell_assignment  <- setNames(metadata$cluster_label,metadata$sample_name)

# This line of code will run all the scripts, output the relevant zip file to nomenclature.zip in your working directory, and return the same variables for further manipulation in R.
ccn_output <- apply_CCN(dend = dend,
                        cell_assignment   = cell_assignment,
                        metadata          = metadata,
                        first_label       = first_label,
                        taxonomy_id       = taxonomy_id,
                        taxonomy_author   = taxonomy_author,
                        taxonomy_citation = taxonomy_citation,
                        structure         = structure,
                        metadata_columns  = metadata_columns,
                        metadata_order    = metadata_order,
                        cluster_column    = cluster_column,
                        ccn_filename      = paste0(refFolder,"nomenclature.zip"))

# Plot the dendrogram (note that this function sometimes does not display the root node correctly)
plot_dend(ccn_output$final_dendrogram,node_size = 3)

# Overwrite the existing dendrogram with the annotated version
dend <- ccn_output$final_dendrogram
saveRDS(dend, file.path(refFolder,"dend.RData")) 

## ----patchseqQC set up--------------------------------------------------------
writePatchseqQCmarkers(counts = paste0(refFolder,"counts.feather"),  # can also read matrix directly
                       metadata = paste0(refFolder,"anno.feather"),  # can also read matrix directly
                       subsample = 100,  # Default of 100 is reasonable
                       subclass.column = "subclass_label",  # default
                       class.column = "class_label",  # default
                       off.target.types = "Non-neuronal",  # default is various iterations of non-neuronal
                       num.markers = 50,     # Default of 50 is probably fine
                       shinyFolder = refFolder)

## ----create annData object----------------------------------------------------
AIT.anndata <- loadTaxonomy(refFolder, hGenes=binary.genes)
write_h5ad(AIT.anndata,file.path(refFolder,"reference.h5ad"))

## ----session info-------------------------------------------------------------
sessionInfo()

