## ----create reference directory-----------------------------------------------
# REPLACE THIS LINE WITH the reference directory folder from "Map patch-seq data and output directory"
refFolder <- paste0(system.file(package = 'scrattch.mapping'),"/reference/")  
# Replase this line with wherever you'd like your mapping output
mappingFolder <- paste0(refFolder,"/mapping/")
dir.create(mappingFolder, showWarnings = FALSE)
print(mappingFolder)

## ----load libraries, warning=FALSE--------------------------------------------
suppressPackageStartupMessages({
  library("scrattch.mapping")
  library("tasic2016data")
})
options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 4000 * 1024^2)  # Can adjust this value if needed, depending on number of cells
options(future.rng.onMisuse="ignore")

## ----load reference taxonomy--------------------------------------------------
AIT.anndata <- read_h5ad(file.path(refFolder,"reference.h5ad"))

## ----load tasic data and subset for mapping-----------------------------------
# Read in data
annotations <- tasic_2016_anno
counts      <- tasic_2016_counts  # uncomment if using CPM below
annotations <- annotations[match(colnames(counts),annotations$sample_name),]  # Put them in the correct order
rownames(annotations) <- annotations$sample_name  
kp          <- annotations$broad_type!="Unclassified"
counts      <- counts[,kp]
annotations <- annotations[kp,]

# Variable renaming
clusters            <- annotations$primary_type_label[match(1:49,annotations$primary_type_id)]
annotations$cluster <- factor(annotations$primary_type_label, levels=clusters)
annotations$class   <- annotations$broad_type
annotations$class[!is.element(annotations$class,c("GABA-ergic Neuron","Glutamatergic Neuron"))] = "Non-neuronal"

# Subsample to get final results
query.kp       <- subsampleCells(annotations$cluster,subSamp=5,seed=10)&(annotations$class!="Non-neuronal")
query.counts   <- counts[,query.kp]
query.metadata <- annotations[query.kp,]
query.logCPM   <- logCPM(query.counts)

## ----general mapping----------------------------------------------------------
query.mapping <- taxonomy_mapping(AIT.anndata= AIT.anndata,
                                  query.data = query.logCPM, 
                                  corr.map   = TRUE, # Flags for which mapping algorithms to run
                                  tree.map   = TRUE, 
                                  seurat.map = TRUE, 
                                  label.cols = c("cluster_label","subclass_label", "class_label") # Columns to map against
)

## ----run buildMappingDirectory------------------------------------------------
buildMappingDirectory(AIT.anndata    = AIT.anndata, 
                      mappingFolder  = mappingFolder,
                      query.data     = query.counts,  # Don't need log-normalized data here
                      query.metadata = query.metadata,
                      query.mapping  = query.mapping,
                      doPatchseqQC   = TRUE  # Set to FALSE if not needed or if writePatchseqQCmarkers was not applied in reference generation
)
dir(mappingFolder)

## ----session info-------------------------------------------------------------
sessionInfo()

